// Add JavaScript logic here
// Get the book list and book details elements
const bookList = document.getElementById('book-list');
const bookDetails = document.getElementById('book-details');
const bookListItems = document.getElementById('book-list-items');
const bookTitle = document.getElementById('book-title');
const bookAuthor = document.getElementById('book-author');
const bookDescription = document.getElementById('book-description');

// Sample book data
const books = [
    { title: 'Book 1', author: 'Author 1', description: 'This is book 1' },
    { title: 'Book 2', author: 'Author 2', description: 'This is book 2' },
    { title: 'Book 3', author: 'Author 3', description: 'This is book 3' }
];

// Generate book list items
books.forEach((book) => {
    const listItem = document.createElement('LI');
    listItem.textContent = book.title;
    listItem.addEventListener('click', () => {
        // Display book details when a list item is clicked
        bookTitle.textContent = book.title;
        bookAuthor.textContent = book.author;
        bookDescription.textContent = book.description;
    });
    bookListItems.appendChild(listItem);
});